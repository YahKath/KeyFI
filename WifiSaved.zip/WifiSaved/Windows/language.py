import subprocess
import colorama 
from colorama import init, Fore, Style
init(autoreset=True)
def main():
    print(Fore.RED + "Which language do you want to run?")
    print("1. English")
    print(Fore.BLUE + "2. Russian")
    print(Fore.RED + "3. Slovak")
    choice = input(Fore.YELLOW + "Enter the number of your choice: ")

    if choice == '1':
        script_name = "EnglishKeyFi.py"
    elif choice == '2':
        script_name = "RussianKeyFI.py"
    elif choice == '3':
        script_name = "SlovakKeyFi.py"
    else:
        print("Invalid choice")
        return

    subprocess.run(["python", script_name])
#Created by YahKath
if __name__ == "__main__":
    main()
